#!/bin/bash

rm success_*